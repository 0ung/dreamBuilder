package codehows.dream.dreambulider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DreamBuliderApplicationTests {

	@Test
	void contextLoads() {
	}

}
