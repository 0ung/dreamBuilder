package codehows.dream.dreambulider.constats;

public enum Authority {
	ROLE_USER,ROLE_ADMIN
}
