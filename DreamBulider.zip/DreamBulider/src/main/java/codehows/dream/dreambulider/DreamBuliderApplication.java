package codehows.dream.dreambulider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DreamBuliderApplication {

	public static void main(String[] args) {
		SpringApplication.run(DreamBuliderApplication.class, args);
	}

}
