package codehows.dream.dreambulider.controller;

import codehows.dream.dreambulider.constats.Authority;
import codehows.dream.dreambulider.dto.Board.BoardAdminListDTO;
import codehows.dream.dreambulider.dto.Board.BoardListResponseDTO;
import codehows.dream.dreambulider.dto.ReplyDTO.ReplyResponseDTO;
import codehows.dream.dreambulider.entity.Board;
import codehows.dream.dreambulider.repository.BoardRepository;
import codehows.dream.dreambulider.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
public class AdminController {

    private final BoardService boardService;

    //관리자 게시물 조회 페이지
    @GetMapping("/api/admin/{page}")
    public ResponseEntity<List<BoardAdminListDTO>> getAdminBoard(@PathVariable Optional<Integer> page) {
        Pageable pageable = PageRequest.of(page.isPresent()? page.get() : 0, 10);
        List<BoardAdminListDTO> board = boardService.getAdminBoardList(pageable)
                .stream()
                .map(BoardAdminListDTO::new)
                .toList();
        return ResponseEntity.ok()
                .body(board);
    }

    //관리자 비활성화 페이지
    @PutMapping("/api/admin")
    public ResponseEntity<Board> invisible (Long id) {
        Board updatedBoard = boardService.invisibleUp(id);

        return ResponseEntity.ok()
                .body(updatedBoard);
    }

}
