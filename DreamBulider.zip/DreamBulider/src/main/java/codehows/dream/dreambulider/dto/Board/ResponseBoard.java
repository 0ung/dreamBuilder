package codehows.dream.dreambulider.dto.Board;


import codehows.dream.dreambulider.entity.Board;
import lombok.Getter;

import java.sql.Date;

@Getter
public class ResponseBoard {
    //아마도 안쓰는거?
//    private final String title;
//    private final String content;
//    private final Date endDate;
//
//    public ResponseBoard(Board board) {
//        this.title = board.getTitle();
//        this.content = board.getContent();
//        this.endDate = board.getEndDate();
//    }
}
