package codehows.dream.dreambulider.dto.NestedReplyDTO;


import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NestedReplyRequestDTO {

    private String comment;

}
