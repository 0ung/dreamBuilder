package codehows.dream.dreambulider.repository;

import codehows.dream.dreambulider.entity.NestedReply;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NestedReplyRepository extends JpaRepository <NestedReply,Long> {
}
