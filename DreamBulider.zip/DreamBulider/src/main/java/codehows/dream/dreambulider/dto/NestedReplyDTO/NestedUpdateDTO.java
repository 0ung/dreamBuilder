package codehows.dream.dreambulider.dto.NestedReplyDTO;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class NestedUpdateDTO {
    private String comment;
}
