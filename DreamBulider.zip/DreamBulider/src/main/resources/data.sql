INSERT INTO board (title, content, end_Date) values ('제목1', '내용1', '2020-01-01');
INSERT INTO board (title, content, end_Date) values ('제목1', '내용1', '2020-01-02');